# Heute Abend – gemeinsamer Client-Arbeitsplan

Ziel der nächsten PC-Sitzung: den vorhandenen Desktop-Launcher mit dem bestehenden lokalen Webserver und Agenten verbinden, nicht parallel einen zweiten Starter aufbauen.

## Vor dem Start
- [ ] Aktuellen Projektordner vollständig sichern.
- [ ] Keine `.env`, Tokens, Passwörter, Zertifikate oder privaten Schlüssel teilen.
- [ ] Vorhandene Playit-Agent-Installation und Tunnelstatus prüfen; keine neuen Agents anlegen.
- [ ] `npm install` nur im Projektordner ausführen, falls Abhängigkeiten fehlen.

## Gemeinsame Prüfung
- [ ] `npm run check:env` (falls im Projekt vorhanden).
- [ ] `npm start` und lokale Website `http://localhost:3000` prüfen.
- [ ] `npm run start:agent` (falls im Projekt vorhanden) und Agentstatus prüfen.
- [ ] Desktop-Launcher starten und IPC/Preload-Verbindung prüfen.
- [ ] Ein Testserver in einem separaten Testverzeichnis starten und stoppen.
- [ ] Logs und tatsächliche Ports prüfen.

## Danach zuerst
1. Launcher-Dashboard an echte API-Daten anbinden.
2. Game Library und Profile implementieren.
3. Serverliste, Konsole und Metriken mit dem Agent verbinden.
4. Erst danach OAuth, Modrinth-Installationen und Community-Module einzeln integrieren.

## Benötigt für die Sitzung
- Zugriff auf den Windows-PC und den bestehenden Projektordner.
- Möglichkeit, Screenshots/Fehlermeldungen zu teilen (ohne Secrets).
- Für Microsoft-Login später eine passende App-Registrierung.
- Für Playit-Automatisierung erst die dokumentierte API-/Kontofunktion verifizieren; Agent-Token niemals in den Chat kopieren.

**Wichtig:** Wir testen nach jeder Änderung. Keine „fertig“-Meldung, solange die jeweilige Abnahme nicht erfolgreich war.
