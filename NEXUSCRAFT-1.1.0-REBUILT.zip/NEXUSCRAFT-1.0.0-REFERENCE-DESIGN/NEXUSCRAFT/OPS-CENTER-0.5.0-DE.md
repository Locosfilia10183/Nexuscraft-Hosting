# NEXUSCRAFT 0.5.0 – Operations Center

## Neu in dieser Version
- NEXUS OS Navigation und neues mobiles Operations Center (`/ops-center.html`).
- Öffentlicher Systemstatus für Website/API, SMP, Karte, Hosting-Agent-Konfiguration und Zahlungsanbieter-Konfiguration.
- Monitoring-Übersicht über in der Control-Plane gespeicherte Server.
- Security-Übersicht mit dem tatsächlichen 2FA-Kontostatus.
- Recovery-Register für geplante Sicherungspunkte.
- Support-Tickets: Benutzer können Tickets anlegen und eigene Tickets sehen; Moderator/Admin/Owner können Status ändern.
- Billing-Übersicht für tatsächliche Credits und Premium-Status des angemeldeten Kontos.
- Sync-Präferenzen für Theme, Sprache und Launcher-/Modpack-Sync.
- Netzwerk-Knotenregister für Admin/Owner.
- Update-Center mit Komponentenstatus und explizitem Hinweis auf noch fehlende signierte Update-/Rollback-Orchestrierung.

## Sicherheits- und Funktionsgrenzen
Diese Version verbindet noch keine neuen externen Dienste. Insbesondere werden keine Datei-Backups erstellt oder wiederhergestellt, keine Zahlungen ausgelöst, keine Node-Prozesse automatisch repariert, keine Netzwerk-Proxies verbunden und keine Launcher-Dateien automatisch aktualisiert. CPU/RAM/TPS-Live-Metriken benötigen einen echten Metrik-Agenten. Die UI zeigt diese Grenzen bewusst an.

## Test
`npm run check:features` prüft die JavaScript-Syntax. Zusätzlich wurde ein lokaler HTTP-Smoke-Test für `/ops-center.html` (HTTP 200) und `/api/nexus/ops/status` erfolgreich ausgeführt.

## Update 0.5.1 – SMP-Status-Zuverlässigkeit
Der öffentliche SMP-Status und das Operations Center werten einen Server nur dann als online, wenn innerhalb des konfigurierten Heartbeat-Zeitfensters ein authentifizierter Heartbeat eingegangen ist. Standard: 90 Sekunden. Bei ausbleibendem Heartbeat wird der Server als offline und die Spielerzahl als 0 angezeigt. Konfiguration: `NEXUS_SMP_HEARTBEAT_TTL_MS` (1.000 bis 300.000 ms).
