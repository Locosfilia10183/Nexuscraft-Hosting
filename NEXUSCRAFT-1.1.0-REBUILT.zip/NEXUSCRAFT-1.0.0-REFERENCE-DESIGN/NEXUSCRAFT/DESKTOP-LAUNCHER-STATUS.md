# NEXUSCRAFT Desktop Launcher – Status

This package adds an Electron Windows desktop companion scaffold. It can connect to the existing Node.js control plane, sign in using the existing `/api/login` endpoint, list the user's servers, and call the existing start/stop/restart routes.

## Build on Windows
1. Install Node.js 20 or newer.
2. Open a terminal in `desktop-launcher`.
3. Run `npm install`.
4. Run `npm start` to test the desktop companion.
5. Run `npm run dist` to create a Windows NSIS installer under `desktop-launcher/dist`.

The desktop companion is not yet a full Minecraft game launcher. Microsoft account OAuth, Minecraft entitlement validation, official game asset/library downloads, version installation, modloader installation, and launching a game process remain to be implemented and tested. It does not include Minecraft files or bypass ownership requirements.

The companion connects to the existing NEXUSCRAFT panel. For remote access, the panel must be reachable over HTTPS and the API must be configured securely. The current backend's cookie/session and cross-origin behavior should be security-reviewed before public production use.
