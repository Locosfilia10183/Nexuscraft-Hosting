# NEXUSCRAFT – Ultimate Roadmap (DE)

**Ziel:** Eine zuverlässige Minecraft-Gaming-, Launcher-, Hosting- und Community-Plattform mit gemeinsamer Website und Windows-Client. Dieses Dokument ergänzt den bisherigen Reliability-Plan. Es ist eine priorisierte Produktspezifikation, keine Behauptung, dass alle Funktionen bereits implementiert sind.

## Leitprinzipien

1. **Zuverlässigkeit vor Funktionsmenge:** Jede Funktion braucht Tests, Fehlerbehandlung und nachvollziehbare Statusanzeigen.
2. **Keine Fake-Daten:** Live-Werte nur aus echten Quellen; ansonsten klar als Demo/Beispiel kennzeichnen.
3. **Sicherheit by design:** Benutzer- und Serverdaten strikt trennen, Least-Privilege, sichere Sitzungen, Audit-Logs und Backups.
4. **Opt-in-Hintergrunddienste:** Agent, Autostart, Updates und Serverbetrieb werden transparent installiert und vom Nutzer kontrolliert.
5. **Gemeinsame Plattform:** Website und Desktop-Client nutzen dieselben Konten, Berechtigungen und versionierte APIs.
6. **Schrittweise Releases:** Jede Phase wird erst nach Abnahme der Tests freigegeben.

## Priorisierte Umsetzung

### P0 – Fundament und Sicherheit (vor neuen Komfortfunktionen)
- Gemeinsame Account-/API-Basis für Website und Launcher; Rollen und Berechtigungen.
- Sichere lokale Agent-Kommunikation, Gerätebindung und widerrufbare Tokens.
- Isolierung je Benutzer: getrennte Serververzeichnisse, Prozesse, Ports, Limits und Berechtigungen.
- Login-Verlauf (17), Rollen-System (18), Audit-Logs, sichere Sitzungen und 2FA-Grundlage.
- Backups mit Wiederherstellungstests; Notfall-Wiederherstellung (21).
- Server-Quarantäne (19) und sicherer Notfall-Stopp.
- Installer-/Updater-Signaturprüfung und transparente Autostart-/Dienst-Optionen.

**Abnahme:** Benutzer A kann weder Dateien, Logs, Konsole noch Backups von Benutzer B lesen oder ändern. Tokens können widerrufen werden. Wiederherstellung aus Backup ist praktisch getestet.

### P1 – Launcher und lokale Spieler-Erfahrung
- Profile Cloud Sync (4): Profile, Versionen und Modlisten synchronisieren; Konflikte behandeln.
- Custom Launcher Themes (1): Themes und Hintergründe, mit gut lesbaren Kontrasten.
- Screenshot-Galerie (2): lokale Galerie, Sortierung und optionales Teilen.
- FPS-/Performance-Anzeige (3): echte Messwerte, keine unbelegten „Booster“-Versprechen; sichere JVM-Optionen.
- Game Library, Versionen, Microsoft-Login, Minecraft-Installation und echter Start.
- Modrinth-Modpack-One-Click-Installation inklusive Loader-/Versionsprüfung, Abhängigkeiten, Updates und Rollback.

**Abnahme:** Installation, Start, Beenden und Fehlerdiagnose eines unterstützten Minecraft-Profils funktionieren auf einem sauberen Windows-Testsystem.

### P2 – Hosting-Kern und Stabilität
- Server-Netzwerk (5): mehrere Instanzen, optional Lobby-/Proxy-Architektur; getrennte Ports und Protokolle.
- Testserver-Klon (9): Snapshot/Kopie zum Testen von Updates, Plugins und Modpacks vor Live-Rollout.
- Automations-Builder (7): sichere Regeln und geplante Tasks mit Vorschau, Limits und Protokoll.
- Live-Weltkarte (8): nur über geeignete Server-Integration und mit Datenschutz-/Berechtigungskontrollen.
- Spieler-Analytics (6): Onlinezeiten und Aktivitätsmetriken mit Aufbewahrungs- und Datenschutzregeln.
- Server-Watchdog, Auto-Recovery, Crash Analyzer, Ressourcenwarnungen und getestete Backups.
- Plugin-/Mod-Kompatibilitätsprüfung und Server-Templates.
- Playit-Integration: bestehende Agent-Installation nutzen, Tunnel-/Portzuordnungen verifizieren; TCP für Java, UDP für Bedrock. Keine erfundenen Adressen oder stillschweigende Tunnel-Erstellung.

**Abnahme:** Start/Stop/Restart, Konsole, Dateien, Spielerlisten, Backups, Wiederherstellung und Tunnel funktionieren für mindestens zwei voneinander isolierte Testnutzer.

### P3 – Community und Social
- Friends/Groups (11), integrierter Voice-Chat (10), Community-Profile (15).
- Öffentliche Serverliste/Marketplace (12) mit Moderation, Meldefunktion und Server-Eigentumsprüfung.
- Events und Turniere (13), Achievements (14), Benachrichtigungen und Einladungslinks.
- Voice nur mit ausdrücklicher Mikrofonfreigabe, Push-to-talk/Deaktivierung und Moderations-/Blockierfunktionen.

**Abnahme:** Blockieren, Melden, Rollen, Einladungsablauf und Moderation sind getestet; private Server bleiben standardmäßig privat.

### P4 – Premium, Domains und Entwicklerplattform
- Premium-Server-Shop (24): nur mit klaren Regeln, Berechtigungen und sicherer Zahlungsintegration; keine Speicherung von Kartendaten.
- Eigene Domains/Subdomains (23): DNS-Verifikation, TLS, Eigentumsprüfung und Schutz vor Domain-Missbrauch.
- Eigene Server-Websites (22): Templates, sichere Veröffentlichung und Zugriffskontrollen.
- Entwickler-API (25): dokumentierte, versionierte API, Scopes, Rate Limits, Webhooks und widerrufbare API-Schlüssel.
- White-Label (27): getrennte Mandanten, Branding-Konfiguration und klare Betreiber-/Support-Zuständigkeiten.

**Abnahme:** Mandanten können nicht aufeinander zugreifen; Domains, API-Schlüssel und Webhooks lassen sich sicher widerrufen.

### P5 – Mobile Control-App
- Mobile Control-App (26): Serverstatus, Start/Stop/Restart, Konsole mit Berechtigungen, Benachrichtigungen und Notfall-Stopp.
- Sichere Geräteanmeldung, 2FA, Sitzungswiderruf und Push-Benachrichtigungen.

**Abnahme:** Mobile App führt nur Aktionen aus, die dem angemeldeten Benutzer auf dem jeweiligen Server erlaubt sind.

## Vollständige Auswahl des Nutzers

| Nr. | Erweiterung | Phase |
|---:|---|---|
| 1 | Custom Launcher Themes | P1 |
| 2 | Screenshot-Galerie | P1 |
| 3 | FPS & Performance | P1 |
| 4 | Profile Cloud Sync | P1 |
| 5 | Server-Netzwerk | P2 |
| 6 | Spieler-Analytics | P2 |
| 7 | Automations-Builder | P2 |
| 8 | Live-Weltkarte | P2 |
| 9 | Testserver-Klon | P2 |
| 10 | NEXUSCRAFT Voice | P3 |
| 11 | Gruppen-System | P3 |
| 12 | Server-Marketplace | P3 |
| 13 | Events & Turniere | P3 |
| 14 | Achievement-System | P3 |
| 15 | Creator-Profile | P3 |
| 16 | Anti-DDoS-Konzept | P0/P2: Netzwerkschutz als Betriebsanforderung, kein alleiniger Client-Schalter |
| 17 | Login-Verlauf | P0 |
| 18 | Rollen-System | P0 |
| 19 | Server-Quarantäne | P0/P2 |
| 20 | Backup-Cloud | P0/P2 |
| 21 | Notfall-Wiederherstellung | P0/P2 |
| 22 | Eigene Server-Websites | P4 |
| 23 | Eigene Domains | P4 |
| 24 | Server-Shop | P4 |
| 25 | API für Entwickler | P4 |
| 26 | Mobile Control-App | P5 |
| 27 | White-Label | P4 |

## Technische Abhängigkeiten und Hinweise

- **Voice, Chat und Community** benötigen Moderation, Blockieren/Melden, Datenschutz- und Aufbewahrungsregeln.
- **Anti-DDoS** erfordert geeignete Infrastruktur/Provider und korrekte Netzwerkarchitektur; eine Desktop-App allein kann das nicht leisten.
- **Cloud-Backups** brauchen Verschlüsselung, Schlüsselverwaltung, Quoten, Integritätsprüfung und Restore-Tests.
- **Eigene Domains** benötigen eine echte Domain/DNS-Verwaltung und TLS-Zertifikate. Eine beliebige `.craft`-Adresse ist nicht automatisch öffentlich auflösbar.
- **White-Label und Marketplace** kommen spät, weil sie Mandantentrennung, Support- und Missbrauchsprozesse voraussetzen.
- **FPS-Optimierung** wird als Messung und sichere Konfigurationshilfe umgesetzt; keine unrealistischen Performance-Garantien.
- **Autostart/Hintergrund-Agent** ist opt-in, sichtbar, deinstallierbar und läuft mit minimal notwendigen Rechten.

## Release-Gates

1. Unit- und Integrationstests für API, Authentifizierung, Berechtigungen und Serververwaltung.
2. Isolationstest mit mehreren Benutzern und parallelen Serverinstanzen.
3. Restore-Test aus Backup und Crash-Recovery-Test.
4. Windows Clean-Install-Test für Installer, Updates, Deinstallation und Autostart-Einstellungen.
5. Sicherheitsprüfung: Secrets nicht im Client, keine offenen Admin-Endpunkte, Rate Limits, Audit-Logs.
6. Erst danach Beta-Rollout; Community-, Marketplace- und Premium-Funktionen schrittweise freischalten.

## Status

Dieses Roadmap-Dokument nimmt alle 27 ausgewählten Erweiterungen in den Gesamtplan auf und ordnet sie nach Abhängigkeiten und Risiko. Es implementiert diese Funktionen nicht automatisch. Die Umsetzung erfolgt in Phasen auf Basis des tatsächlichen NEXUSCRAFT-Quellcodes und wird pro Release getestet.
