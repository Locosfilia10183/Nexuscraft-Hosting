param(
  [ValidateSet("check","install","web","agent","launcher","build-win")]
  [string]$Action = "check"
)
$ErrorActionPreference = "Stop"
function Need($name,$args) {
  $cmd = Get-Command $name -ErrorAction SilentlyContinue
  if (-not $cmd) { throw "$name wurde nicht gefunden. Installiere es und öffne PowerShell neu." }
  & $name @args
  if ($LASTEXITCODE -ne 0) { throw "$name ist mit Exitcode $LASTEXITCODE fehlgeschlagen." }
}
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
$node = (node --version).Trim()
if (-not $node.StartsWith("v24.")) { Write-Warning "Erkannt: Node $node. Empfohlen ist Node.js 24." }
switch ($Action) {
  "check" {
    Write-Host "NEXUSCRAFT Umgebung" -ForegroundColor Cyan
    node --version; npm --version
    try { java -version } catch { Write-Warning "Java nicht gefunden. Minecraft-Spielstart benötigt eine passende Java-Version." }
    Write-Host "Projekt: $root"
    Write-Host "Keine BAT-Dateien erforderlich."
  }
  "install" {
    Need npm @("install")
    Need npm @("--prefix","desktop-launcher","install")
  }
  "web" {
    if (-not (Test-Path ".env")) { throw "Datei .env fehlt. Kopiere .env.example nach .env und trage sichere Werte ein." }
    Need node @("server.js")
  }
  "agent" {
    if (-not (Test-Path ".env")) { throw "Datei .env fehlt. Konfiguration zuerst einrichten." }
    Need node @("agent/agent.js")
  }
  "launcher" {
    Need npm @("--prefix","desktop-launcher","start")
  }
  "build-win" {
    Need npm @("--prefix","desktop-launcher","install")
    Need npm @("--prefix","desktop-launcher","run","dist:win")
    Write-Host "Build-Ausgabe: desktop-launcher\dist" -ForegroundColor Green
  }
}
