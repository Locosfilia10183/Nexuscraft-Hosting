'use strict';
const {spawn}=require('child_process');
const fs=require('fs');
const os=require('os');
const path=require('path');
const data=path.join(os.tmpdir(),'nexuscraft-smp-heartbeat-'+process.pid+'.json');
const feature=path.join(os.tmpdir(),'nexuscraft-smp-feature-'+process.pid+'.json');
for(const f of [data,feature])try{fs.unlinkSync(f)}catch{}
const port=32000+(process.pid%10000);
const token='test-heartbeat-token-which-is-long-enough';
const child=spawn(process.execPath,['server.js'],{cwd:path.resolve(__dirname,'../..'),env:{...process.env,PORT:String(port),DATA_FILE:data,FEATURE_DATA_FILE:feature,NEXUS_SMP_HEARTBEAT_TOKEN:token,NEXUS_SMP_HEARTBEAT_TTL_MS:'1000'},stdio:'ignore'});
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{try{
 const base=`http://127.0.0.1:${port}`; let ready=false;
 for(let i=0;i<40;i++){try{const r=await fetch(base+'/api/nexus/public-smp');if(r.ok){ready=true;break}}catch{}await sleep(100)}
 if(!ready)throw Error('server did not start');
 let r=await fetch(base+'/api/nexus/smp/heartbeat',{method:'POST',headers:{'content-type':'application/json','x-smp-token':token},body:JSON.stringify({online:true,players:7,maxPlayers:100,version:'test'})});
 if(r.status!==200)throw Error('valid heartbeat rejected: '+r.status);
 r=await fetch(base+'/api/nexus/public-smp');let j=await r.json();
 if(!j.online||j.players!==7||j.heartbeatFresh!==true)throw Error('fresh heartbeat not reflected: '+JSON.stringify(j));
 await sleep(1200);
 r=await fetch(base+'/api/nexus/public-smp');j=await r.json();
 if(j.online||j.players!==0||j.heartbeatFresh!==false)throw Error('stale heartbeat still shown online: '+JSON.stringify(j));
 r=await fetch(base+'/api/nexus/ops/status');j=await r.json();
 if(j.onlineSmp!==false||j.services.find(x=>x.name==='Public SMP')?.status!=='offline')throw Error('operations status did not expire heartbeat');
 console.log('PASS authenticated SMP heartbeat; online status expires after TTL; stale player count resets; Operations Center agrees');
}catch(e){console.error(e);process.exitCode=1}finally{child.kill();for(const f of [data,feature])try{fs.unlinkSync(f)}catch{}}})();
