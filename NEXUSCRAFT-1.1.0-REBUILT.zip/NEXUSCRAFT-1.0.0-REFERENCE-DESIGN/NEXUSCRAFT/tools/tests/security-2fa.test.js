const {spawn}=require('child_process');const fs=require('fs');const crypto=require('crypto');
const path=require('path');const os=require('os');const data=path.join(os.tmpdir(),'nexuscraft-security-test-'+process.pid+'.json');try{fs.unlinkSync(data)}catch{}
const child=spawn(process.execPath,['server.js'],{cwd:path.resolve(__dirname,'../..'),env:{...process.env,PORT:'31987',DATA_FILE:data},stdio:'ignore'});
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function unb32(input){const a='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';let bits=0,v=0,o=[];for(const c of input){v=(v<<5)|a.indexOf(c);bits+=5;if(bits>=8){o.push((v>>>(bits-8))&255);bits-=8}}return Buffer.from(o)}
function code(secret){const b=Buffer.alloc(8);b.writeBigUInt64BE(BigInt(Math.floor(Date.now()/30000)));const h=crypto.createHmac('sha1',unb32(secret)).update(b).digest(),o=h[h.length-1]&15;return String((h.readUInt32BE(o)&0x7fffffff)%1e6).padStart(6,'0')}
(async()=>{try{let base='http://127.0.0.1:31987';await sleep(500);
async function req(path,method='GET',body,cookie){let r=await fetch(base+path,{method,headers:{...(method==='GET'?{}:{'content-type':'application/json'}),...(cookie?{cookie}: {})},body:body?JSON.stringify(body):undefined});let j=await r.json();return {status:r.status,j,c:r.headers.get('set-cookie')?.split(';')[0]}}
let r=await req('/api/register','POST',{email:'test@example.com',username:'tester',password:'password123'});if(r.status!==200||!r.c)throw Error('register/login failed '+JSON.stringify(r));let ck=r.c;
r=await req('/api/auth/2fa/setup','POST',{},ck);if(r.status!==200||!r.j.secret)throw Error('setup failed '+JSON.stringify(r));let secret=r.j.secret;
r=await req('/api/auth/2fa/enable','POST',{code:code(secret)},ck);if(r.status!==200||r.j.recoveryCodes?.length!==10)throw Error('enable failed '+JSON.stringify(r));
await req('/api/logout','POST',{},ck);
r=await req('/api/login','POST',{email:'test@example.com',password:'password123'});if(!r.j.twoFactorRequired)throw Error('2FA challenge missing '+JSON.stringify(r));
let challenge=r.j.challengeToken;r=await req('/api/auth/2fa/verify-login','POST',{challengeToken:challenge,code:code(secret)});if(r.status!==200||!r.c)throw Error('2FA verify failed '+JSON.stringify(r));ck=r.c;
r=await req('/api/auth/sessions','GET',null,ck);if(r.status!==200||r.j.sessions.length!==1||!r.j.sessions[0].current)throw Error('session list failed '+JSON.stringify(r));
console.log('PASS register, 2FA setup/enable, 2FA login challenge, TOTP verification, session list');
}catch(e){console.error(e);process.exitCode=1}finally{child.kill();try{fs.unlinkSync(data)}catch{}}})();
