param([switch]$BuildLauncher)
$ErrorActionPreference = 'Stop'
Write-Host 'NEXUSCRAFT 3.4 - Systemcheck' -ForegroundColor Cyan
node --version
npm --version
node --check .\server.js
node --check .\agent\agent.js
node --check .\desktop-launcher\main.js
node --check .\desktop-launcher\preload.js
if ($LASTEXITCODE -ne 0) { throw 'JavaScript-Prüfung fehlgeschlagen.' }
if (-not (Get-Command java -ErrorAction SilentlyContinue)) {
  Write-Warning 'Java nicht gefunden. Minecraft-Start ist auf diesem PC noch nicht möglich.'
} else { java -version }
if ($BuildLauncher) {
  Push-Location .\desktop-launcher
  try { npm install; if ($LASTEXITCODE -ne 0) { throw 'npm install fehlgeschlagen' }; npm run dist:win; if ($LASTEXITCODE -ne 0) { throw 'Windows-Build fehlgeschlagen' } }
  finally { Pop-Location }
}
Write-Host 'Syntaxcheck abgeschlossen. OAuth, Spielstart, Modpacks und Node-Erreichbarkeit müssen real getestet werden.' -ForegroundColor Green
