# NEXUSCRAFT Client 3.2

## Implementiert
- Microsoft-Anmeldung über MSMC mit offiziellem Xbox-/Minecraft-Tokenfluss.
- Prüfung der Minecraft-Java-Entitlements vor dem Start.
- Lokale Sitzung nur im laufenden Prozess; Tokens werden nicht als Klartext gespeichert.
- Minecraft Java-Dateien, Libraries, Assets und Startargumente über minecraft-launcher-core.
- Vanilla sowie Fabric-, Forge-, NeoForge- und Quilt-Installer-Adapter (noch auf Windows zu testen).
- Java-Erkennung, RAM-Zuweisung, Start-/Stop-IPC und Log-/Fortschrittsereignisse.

## Noch zu testen / Grenzen
- Microsoft-/Minecraft-Dienste können neue App-Registrierung, API-Freigabe oder Änderungen am Auth-Flow verlangen. MSMC verwendet den von der Bibliothek vorgesehenen Login-Flow; Live-Anmeldung muss auf Windows mit einem echten Konto getestet werden.
- Forge-/NeoForge-Metadaten- und Installer-Aufruf sind implementiert, müssen aber auf Windows mit mehreren konkreten Versionen getestet werden.
- Fabric-/Quilt-Installer-Aufruf und MCLC-Profilauflösung müssen auf einem Windows-PC mit mehreren Minecraft-Versionen verifiziert werden.
- Minecraft Java Edition muss dem Benutzer gehören. Keine Offline-/Cracked-Authentifizierung, keine mitgelieferten Mojang-Dateien.
- Erste Installation lädt große Datenmengen herunter; stabile Internetverbindung und genügend Speicherplatz erforderlich.
- Der Client ist Java Edition für Windows. Bedrock wird nicht durch diesen Launcher gestartet.

## Build
Im Ordner `desktop-launcher`: `npm install` und danach `npm run dist:win`.
