# NEXUSCRAFT Launcher 3.1 – Client groundwork

Implemented in this build:
- Fetches the official Mojang version manifest and lists current release versions.
- Saves, lists and deletes local launcher profiles in the Electron user-data directory.
- Profile data includes name, Minecraft version, loader selection and RAM allocation.
- Searches public Modrinth modpacks and opens the selected project page.
- Keeps Electron renderer isolated; network calls and local file writes happen in the main process.

Not yet implemented and therefore not advertised as working:
- Microsoft/Xbox/Minecraft OAuth and entitlement validation.
- Downloading and verifying Minecraft client libraries/assets.
- Fabric/Forge/NeoForge/Quilt installer integration.
- Actual game process launch, Java runtime selection and crash reporting.
- CurseForge API integration (requires an official API key and compliance with its terms).

No game files are bundled. Users must authenticate with a Microsoft account that owns Minecraft before a future real launch implementation is enabled.
