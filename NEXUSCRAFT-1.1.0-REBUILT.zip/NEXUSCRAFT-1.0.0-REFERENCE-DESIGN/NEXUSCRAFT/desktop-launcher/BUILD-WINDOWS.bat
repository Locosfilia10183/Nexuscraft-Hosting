@echo off
setlocal
cd /d "%~dp0"
echo ==========================================
echo       NEXUSCRAFT LAUNCHER BUILDER
echo ==========================================
where node >nul 2>nul || (echo Node.js fehlt. Installiere Node.js 20 LTS oder neuer.& pause& exit /b 1)
where npm >nul 2>nul || (echo npm fehlt.& pause& exit /b 1)
echo Installiere Launcher-Abhaengigkeiten...
call npm install || (echo npm install fehlgeschlagen.& pause& exit /b 1)
echo Baue Windows Installer und portable EXE...
call npm run dist:win
if errorlevel 1 (echo Build fehlgeschlagen. Siehe Fehlermeldung oben.& pause& exit /b 1)
echo Fertig. Dateien liegen in desktop-launcher\dist\
pause
