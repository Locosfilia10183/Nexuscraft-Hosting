# NEXUSCRAFT 3.3 — Unified Engineering Pack

This archive consolidates the existing 3.2 source and adds a PowerShell-first Node 24 workflow.
It is a development package, **not a claim that every listed production feature is complete**.

## What is present in the source
- Electron desktop launcher shell with isolated preload bridge.
- Existing Microsoft sign-in / Minecraft entitlement integration attempt using `msmc`.
- Existing Minecraft launcher-core download/launch path.
- Existing Fabric, Forge, NeoForge and Quilt installer adapters.
- Existing Modrinth search entry point.
- Existing Node.js website/backend and Windows-capable node agent.
- New `tools/nexuscraft.ps1` commands; no `.bat` is required.

## Must be completed and verified before calling it production-ready
1. Microsoft OAuth: register a supported public-client application, configure redirect/device flow and validate current Xbox/Minecraft service requirements. Do not embed a client secret in the app.
2. Minecraft entitlement: test against real accounts with and without Java entitlement; fail closed. The current code path is an integration attempt, not verified in this environment.
3. Game runtime: verify manifest downloads, SHA checks, native libraries, Java runtime selection, arguments, process lifecycle, offline/crash recovery, and all four loader installers against supported game versions.
4. Modrinth: resolve version dependencies and client-side files, verify hashes, install into isolated instances, support updates/rollback.
5. CurseForge: requires an approved API key and compliance with CurseForge API terms. No key is included.
6. iOS: the web app can be installed as a PWA; a native IPA requires a native iOS project, macOS/Xcode build, Apple signing certificate and provisioning profile. This Windows/Node archive cannot produce a valid signed IPA.
7. Multi-node hosting: requires multiple reachable machines, unique node credentials, TLS, firewall rules, resource reservations, persistent storage, backups, monitoring, database migration/HA, and recovery tests. The existing agent is not a complete orchestrator.
8. Updates/sync: implement signed release manifests, staged rollout, rollback, conflict handling and per-platform updater. Do not auto-update unsigned binaries.

## PowerShell commands (Node.js 24)
From the extracted `NEXUSCRAFT` folder:
- `.\tools\nexuscraft.ps1 -Action check`
- `.\tools\nexuscraft.ps1 -Action install`
- `.\tools\nexuscraft.ps1 -Action web`
- `.\tools\nexuscraft.ps1 -Action agent`
- `.\tools\nexuscraft.ps1 -Action launcher`
- `.\tools\nexuscraft.ps1 -Action build-win`

`web` and `agent` require a configured `.env`. Keep `.env`, `agent/agent-config.json`, node tokens, OAuth secrets and API keys private.

## Platform notes
- Node 24 is used for the website, backend and tooling.
- Minecraft itself needs a compatible Java runtime. Use the runtime requirement of the selected Minecraft release; do not assume Node replaces Java.
- A Windows `.exe` can be built on Windows using electron-builder.
- A native iOS `.ipa` requires Apple signing and Xcode on macOS. A PWA is the immediate iPhone option.
