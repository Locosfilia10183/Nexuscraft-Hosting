# NEXUSCRAFT – P0 Sicherheitsschritt 2

## Eingebaut
- TOTP-Zwei-Faktor-Authentifizierung ohne zusätzliche npm-Abhängigkeit (Authenticator-Apps mit 30-Sekunden-Code).
- 2FA-Setup mit zeitlich begrenztem Pending-Secret (10 Minuten) und Aktivierung erst nach erfolgreicher Codeprüfung.
- 2FA-Abfrage nach korrektem Passwort beim Login; Challenge läuft nach 5 Minuten ab und wird nach 5 Fehlversuchen ungültig.
- 10 einmalig verwendbare Wiederherstellungscodes; gespeichert werden nur SHA-256-Hashes.
- 2FA-Status, Deaktivierung mit aktuellem TOTP-Code und Widerruf aller Sitzungen bei Deaktivierung.
- Sitzungsübersicht mit Gerät/User-Agent, IP, Erstellungszeit und aktueller Sitzung.
- Einzelne andere Sitzungen oder alle anderen Sitzungen können widerrufen werden.
- Rate-Limits für Setup, Aktivierung, Deaktivierung und Login-Verifikation.
- Audit-Ereignisse für Aktivierung, Deaktivierung und erfolgreiche 2FA-Anmeldung.
- Konto-Sessions enthalten jetzt Geräte-Metadaten.

## Verwendung
1. Website starten und anmelden.
2. Unter **Konto → Sicherheit → 2FA einrichten** den angezeigten geheimen Schlüssel manuell in Google Authenticator, Microsoft Authenticator, Aegis oder eine kompatible TOTP-App eintragen.
3. Den sechsstelligen Code eingeben und **2FA aktivieren** drücken.
4. Alle zehn Wiederherstellungscodes sicher und offline speichern. Sie werden nur einmal angezeigt.
5. Bei künftigen Anmeldungen zuerst E-Mail/Passwort und danach TOTP-Code eingeben. Ein Wiederherstellungscode kann stattdessen einmalig verwendet werden.
6. Unter **Angemeldete Geräte** Sitzungen prüfen und einzeln oder gesammelt abmelden.

## Tests
`node tools/tests/security-2fa.test.js`

Der Integrationstest prüft Registrierung/Login, 2FA-Setup, Aktivierung, Login-Challenge, TOTP-Verifikation und Sitzungsübersicht.

## Wichtige Grenzen / Produktionshinweise
- Der TOTP-Geheimschlüssel liegt aktuell im lokalen `data.json` im Klartext. Die Datei muss durch Windows-Dateirechte geschützt werden und darf niemals öffentlich ausgeliefert oder in ZIPs/Backups geteilt werden. Vor öffentlichem Mehrbenutzerbetrieb sollte die Datenbankverschlüsselung bzw. ein geschützter Schlüssel-Speicher ergänzt werden.
- Die Oberfläche zeigt den TOTP-Schlüssel und die otpauth-URI als Text; ein QR-Code wird in diesem Schritt noch nicht erzeugt.
- Sitzungs-IP-Adressen und User-Agent-Angaben sind Hinweise zur Geräteerkennung und keine sichere Geräteidentität.
- Das Projekt verwendet weiterhin `data.json`; parallele Schreibzugriffe und atomare Transaktionen sind damit noch nicht ausreichend gelöst. SQLite/Migrationen bleiben ein eigener P0-Schritt.
- Die Tests laufen lokal mit einem temporären Datenspeicher. Microsoft-Login, Playit, Minecraft-Prozesse, Windows-Dienstinstallation und die Electron-EXE werden hierdurch nicht getestet.
