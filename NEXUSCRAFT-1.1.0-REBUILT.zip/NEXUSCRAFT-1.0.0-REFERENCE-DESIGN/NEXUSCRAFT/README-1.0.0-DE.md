# NEXUSCRAFT 1.0.0 – Reference Design

## Start
1. Install Node.js 20 LTS or newer.
2. Extract the ZIP.
3. Open PowerShell in this folder.
4. Run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

## Desktop launcher (development)
1. Open a second PowerShell in `desktop-launcher`.
2. Run `npm install`.
3. Run `npm start`.

## Windows EXE build
On a Windows PC with Node.js 20 LTS or newer:
- Double-click `desktop-launcher/BUILD-WINDOWS.bat`.
- Installer and portable EXE are written to `desktop-launcher/dist/`.

This ZIP does not contain a prebuilt EXE. A Windows build has not been run or verified in this environment.

## What changed in 1.0.0
- Reworked launcher navigation to match the supplied nine-screen NEXUSCRAFT reference.
- Added dedicated Modrinth, Mods, Resource Packs, Shader, Friends and Account views.
- Updated the visual system to dark charcoal and neon purple with responsive navigation.
- Existing working server, login and Minecraft client flows were preserved.

## Honest feature status
- Existing backend server list and server start/stop/restart actions depend on a connected and configured panel/node.
- Microsoft sign-in and Minecraft Java launch require a valid Minecraft Java account and Windows runtime testing.
- Modrinth search is available in the existing client area. Full one-click modpack dependency installation is not certified.
- Mods, Resource Packs, Shader management and launcher-side Friends/Premium management are clearly marked as not yet connected. No fake data or fake live metrics are displayed.
- The public SMP remains offline until a real authenticated heartbeat is received.

## Checks performed for this package
- `node --check desktop-launcher/renderer/app.js`
- `node --check server.js`
- `node --test tools/tests/*.test.js` – 2 tests passed.
