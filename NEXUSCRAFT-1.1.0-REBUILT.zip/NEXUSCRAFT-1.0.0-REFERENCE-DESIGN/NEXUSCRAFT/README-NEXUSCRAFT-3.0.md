# NEXUSCRAFT 3.0 – Unified platform starter

This package combines the existing Node.js hosting control plane and Windows node agent with a first Electron desktop companion shell. It is a development starter, not a finished commercial hosting platform or playable Minecraft launcher.

## Included now
- Existing Node.js control plane (`server.js`) and agent (`agent/agent.js`).
- Existing mobile-first web panel/PWA (`public/`).
- Electron desktop companion with account login/register, server list, start/stop/restart, node status, and a Minecraft profile-selection UI.
- Windows installer/portable build script (`desktop-launcher/BUILD-WINDOWS.bat`).
- GitHub Actions workflow to build Windows artifacts and publish them as a downloadable workflow artifact.

## Start web panel + local agent on Windows
1. Install Node.js 20+ and a suitable Java runtime.
2. Copy `.env.example` to `.env`. Keep secrets empty unless you have real credentials. Never commit `.env`.
3. Run `start-all.bat`.
4. Open `http://localhost:3000`. The first registered account becomes owner.
5. Keep the agent token private in `agent/agent-config.json`.

## Build desktop app
1. Install Node.js 20+ on Windows.
2. Open `desktop-launcher` and double-click `BUILD-WINDOWS.bat`.
3. Outputs appear in `desktop-launcher/dist/`.
4. Alternatively upload the project to GitHub and run Actions → Build NEXUSCRAFT Windows Launcher. Download the artifact from the completed run.

## Connect desktop app
Use the HTTPS URL of your deployed panel (or `http://localhost:3000` for local testing), then sign in with your panel account. The desktop app can manage existing servers via the current backend API.

## Honest feature boundaries
- The desktop app is currently a hosting companion plus Minecraft profile UI, not yet a playable Minecraft Java client. Microsoft OAuth/device-code authentication, entitlement checks, official game asset/version downloads, modloader installation, safe library management and process launch still need implementation and testing.
- Do not bundle Minecraft game files. Users must own Minecraft Java Edition and authenticate through Microsoft's official flow.
- iPhone install is currently the existing PWA: open the deployed HTTPS website in Safari and use Share → Add to Home Screen. This is not a signed native IPA.
- Bedrock client support is separate; Java launcher support does not launch Bedrock.
- Public hosting requires HTTPS, secure secrets, backups, firewall rules, monitoring, and a reachable game node. A local PC must remain on to host from that PC.
- Free providers may impose verification, sleep, bandwidth, CPU/RAM, and usage limits. No provider is guaranteed to be verification-free.

## Security
Never publish `.env`, `agent/agent-config.json`, API keys, payment keys, SMTP passwords, or node tokens. Use HTTPS for remote panel access. Review firewall exposure before binding the agent to a public interface.

## Launcher 3.1 additions
The desktop client now retrieves the official Mojang release catalogue, stores local launcher profiles (name/version/loader/RAM), and searches public Modrinth modpacks. These are metadata/profile functions only. A playable launcher still requires Microsoft OAuth, Minecraft entitlement validation, official game-file/library downloads, modloader installation, Java runtime selection, and launch/crash testing. See `desktop-launcher/CLIENT-STATUS-3.1.md`.
