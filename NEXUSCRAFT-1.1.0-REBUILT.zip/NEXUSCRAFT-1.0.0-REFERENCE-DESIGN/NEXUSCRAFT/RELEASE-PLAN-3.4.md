# NEXUSCRAFT 3.4 – integrierte Plattformbasis

## In diesem Paket enthalten
- Bestehende Node.js-Control-Plane, Web-PWA und Hosting-Agent aus 3.3 bleiben zusammen.
- Bestehender Electron-Client mit Microsoft-/Minecraft-Login- und Spielstartpfad bleibt enthalten.
- Desktop-Paketversion auf 0.3.4 angehoben.
- Electron-Updatekanal über GitHub Releases ergänzt: Prüfung in installierten Builds, manuelles Laden/Installieren über IPC.
- Windows-GitHub-Actions-Workflow ergänzt: Syntaxcheck, Windows-EXE/Portable-Build und Release-Anhänge bei `v*`-Tags.
- PowerShell-Systemcheck/Buildhilfe `tools/release-check.ps1` (keine BAT-Datei erforderlich).

## Was damit noch NICHT bewiesen ist
- Der Minecraft-Client ist nicht durch einen echten Microsoft-Account-Login und Spielstart auf Windows abgenommen.
- Loader-Installationen und Modpack-Kombinationen sind nicht systematisch durchgetestet.
- CurseForge benötigt einen gültigen API-Key und zulässigen API-Zugang.
- Multi-Node bedeutet aktuell registrierte Agent-Nodes und Zuweisung; kein Kubernetes-Cluster, keine Live-Migration und kein automatisches Failover.
- Eine iPhone-PWA ist möglich; eine native IPA muss mit Xcode/macOS, Apple Signing und realen iOS-Geräten gebaut/getestet werden.
- Update-Signaturprüfung ist eingeschaltet. Für öffentliche Verteilung muss ein gültiges Windows-Code-Signing-Zertifikat in der Build-Umgebung eingerichtet werden. Ohne Zertifikat kann Windows SmartScreen warnen.
- Die GitHub-Action benötigt Schreibrechte für Releases im Repository und wird erst durch Push eines `v*`-Tags veröffentlicht.

## Windows-PC
Im Projektordner PowerShell öffnen:
```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\tools\release-check.ps1
```
Für den lokalen Windows-Launcher-Build:
```powershell
.\tools\release-check.ps1 -BuildLauncher
```
Der fertige Build liegt danach unter `desktop-launcher\dist\`.

## GitHub Release
Nach erfolgreichem Test und eingerichtetem Signing:
```powershell
git tag v0.3.4
git push origin v0.3.4
```
Die Action baut die Windows-Artefakte und hängt sie an den GitHub-Release. Nicht vor dem lokalen Test taggen.

## Kritische Zugangsdaten
`.env`, `data.json`, `nodes.json`, `agent/agent-config.json`, Microsoft-/CurseForge-/Stripe-Schlüssel und Signing-Zertifikate niemals committen oder in Chats teilen.
