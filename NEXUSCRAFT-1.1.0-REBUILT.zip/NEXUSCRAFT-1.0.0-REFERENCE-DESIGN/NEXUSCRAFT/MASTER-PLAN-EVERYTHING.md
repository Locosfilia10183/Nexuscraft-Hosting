# NEXUSCRAFT — Masterplan: Everything, Reliability First

## Zielbild
NEXUSCRAFT wird eine Windows-first Minecraft-Plattform mit Desktop-Launcher, Modrinth-Bibliothek, zentralem Hosting-Agent auf dem eigenen Windows-PC, Web-Dashboard, Community-Funktionen und Admin-Control-Center. Der vorhandene Rechner ist zunächst der einzige Hosting-Node. Jeder Benutzer und jede Instanz erhält eine strikt getrennte Datenablage, Konfiguration, Prozessidentität und Ressourcenlimits.

**Wichtig:** Dieses Paket enthält den bisherigen NEXUSCRAFT-3.6-Projektstand plus diesen vollständigen Umsetzungs- und Abnahmeplan. Es ist kein fertig integriertes Produktionssystem. Funktionen, die externe OAuth-Zugangsdaten, Playit-Konfiguration, Windows-Tests oder weitere Backend-Arbeit benötigen, werden ausdrücklich als offen geführt. Keine Oberfläche darf Live-Werte oder erfolgreiche Aktionen vortäuschen.

## Produktbereiche und Funktionsumfang

### A. Desktop-Launcher
- Microsoft-Kontoanmeldung über offiziellen OAuth-/Xbox-/Minecraft-Authentifizierungsablauf; Tokens verschlüsselt im Windows Credential Manager speichern, niemals im Klartext oder in Logs.
- Minecraft Java-Versionen und Installationen verwalten; offizielle Assets/Libraries beziehen; korrekte Java-Runtime pro Version auswählen.
- Profile und Instanzen mit separaten Game-Verzeichnissen, RAM-/JVM-Einstellungen und Startargumenten.
- Start/Stop, Fortschrittsstatus, Spiel- und Crash-Logs, Diagnoseexport.
- Launcher- und Komponentenupdates mit Signatur-/Hashprüfung und Rollback.

### B. Modrinth & Content
- Modrinth-Projekt-/Versionssuche mit Loader-, Spielversions- und Kategorie-Filtern.
- Installieren, aktualisieren, entfernen und Versionen pinnen.
- Abhängigkeiten automatisch auflösen; inkompatible Loader/Spielversionen vor Installation blockieren oder klar warnen.
- Modpacks importieren/exportieren; Profile isolieren; Ressourcenpakete, Shader und Datapacks verwalten.
- Vor Änderungen Backup des betroffenen Profils erstellen.

### C. Hosting-Node (Windows-PC)
- Lokaler Node-Agent mit authentifizierter, nur lokal erreichbarer Control API; Web-UI darf keine beliebigen Shell-Befehle ausführen.
- Servertypen: Vanilla, Paper, Purpur, Spigot, Fabric, Forge, NeoForge, Quilt und Folia, soweit jeweilige Versionen verfügbar sind.
- Server erstellen, starten, stoppen, neu starten, löschen, importieren und aktualisieren.
- Pro Instanz eindeutige UUID, Verzeichnis, Prozess, Portzuordnung, Logs, Konfiguration, Welt, Backups und Limits.
- Java- und Bedrock-Server; GeyserMC/Floodgate als explizit installierte und versionierte Komponenten.
- Live-Konsole mit Allowlist/rollenbasierten Aktionen; Spieler, Whitelist, OP, Ban, Properties, Plugins/Mods und Dateiverwaltung.
- Ressourcenlimits: RAM-Min/Max, CPU-Anteil soweit Windows-seitig belastbar, Speicherquote, Spielerlimit und Startparallelität.
- Schutz gegen Pfad-Traversal, Symlink-Ausbruch, fremde Instanzpfade, unsichere Uploads und Prozess-Manipulation.

### D. Playit.gg & öffentliche Adressen
- Vorhandenen Agent `from-key-5eaf` weiterverwenden; keinen zweiten Agent ohne Grund anlegen.
- Tunnelkonfiguration nur über unterstützte Playit-Funktionen/API oder manuell bestätigte Einstellungen integrieren. Keine erfundene API und keine angenommene automatische Tunnel-Erstellung.
- Java-Tunnel: TCP; Bedrock-Tunnel: UDP. Port-/Tunnel-Zuordnung je Serverinstanz dokumentieren und Konflikte verhindern.
- Öffentliche Adresse/Port erst anzeigen, wenn sie tatsächlich von Playit bestätigt wurden.
- `.craft` ist keine allgemein registrierte öffentliche DNS-Endung. Eigene Domain oder vom Tunnelanbieter bereitgestellter Hostname verwenden.
- Agent-Secret niemals in Frontend, Chat, Git, Logs oder ZIP ablegen; bei Verdacht rotieren.

### E. Website, Konten und Credits
- Gemeinsame Identität für Website und Desktop-App.
- Registrierung, Login, E-Mail-Verifikation, Passwort-Reset, Sitzungsverwaltung und optional TOTP-2FA.
- Rollen: User, Support, Moderator, Admin, Owner; jede Admin-Aktion mit Audit-Log.
- Credits: Startguthaben 10.000 pro neuem Konto; serverseitige Buchungen mit unveränderlichem Ledger, Idempotenz und Schutz vor doppelter Abbuchung.
- Premium-Entitlements und Admin-Freischaltung; keine Berechtigung allein durch Client-Daten.
- Rate-Limits, CSRF-Schutz, sichere Cookies, Passwort-Hashing (Argon2id), Eingabevalidierung und Account-Sperren.

### F. Community
- Freundesliste, Einladungen, Gruppen und Benachrichtigungen.
- Öffentliche Serverliste mit Opt-in, Serverbeschreibung, Version, Status und Moderations-/Meldewerkzeugen.
- Bewertungen erst nach verifizierter Teilnahme; Spam-/Missbrauchsschutz.
- Chat nur mit Melde-, Blockier- und Moderationsfunktionen; Datenschutz und Aufbewahrungsfristen festlegen.

### G. Admin-Control-Center
- Benutzer-/Rollen-/Premiumverwaltung, Credits, Limits und Sperren.
- Node- und Instanzübersicht, Ressourcenalarme, Wartungsmodus und Notfall-Stopp.
- Audit-Logs, Backupstatus, Fehler-/Crashübersicht und Diagnoseexport.
- Admin-Änderungen mit Bestätigung und nachvollziehbarem Protokoll.

### H. Betrieb & Zuverlässigkeit
- Automatische Backups mit Aufbewahrungsregeln und regelmäßig getesteter Wiederherstellung.
- Auto-Recovery mit Crash-Loop-Limit und Benachrichtigung; kein endloser Neustart.
- Crash Analyzer, strukturierte Logs, Healthchecks und Statushistorie.
- Geplante Neustarts, Updates und Wartungsfenster.
- Resource Alerts für RAM, CPU, Datenträger und Netzwerk.
- Später Multi-Node-Unterstützung; zunächst nur ein Windows-Node, Architektur aber nodefähig.

## Verbindliche Umsetzungsreihenfolge (Reliability First)

### Phase 0 — Bestand sichern und inventarisieren
1. Originalprojekt unverändert sichern.
2. Abhängigkeiten und vorhandene Funktionen prüfen; keine bestehenden Dateien blind überschreiben.
3. `.env`, Tokens, Zertifikate, private Schlüssel und lokale Daten aus Git/ZIP ausschließen.
4. Tests für vorhandene API-Routen, Agent-Verbindung und Launcher-IPC ergänzen.

**Abnahme:** Backup vorhanden; keine Secrets im Repository/Release; Start und Healthcheck reproduzierbar.

### Phase 1 — Stabiler lokaler Kern
1. Node-Agent und Webserver mit klaren Rollen und Authentifizierung trennen.
2. Instanzdatenmodell und sichere Verzeichnisisolation implementieren.
3. Prozessmanager für Start/Stop/Restart mit Allowlist und Limits.
4. Portreservierung und Konfliktprüfung.
5. Audit-Logs, Fehlerbehandlung, Healthchecks.

**Abnahme:** Zwei Testkonten können je eine getrennte Testinstanz anlegen; keine gegenseitigen Datei-/Konsolenzugriffe; Prozesse und Ports werden korrekt beendet/freigegeben.

### Phase 2 — Echter Minecraft-Serverbetrieb
1. Download- und Versionsmetadaten verifizieren.
2. Vanilla und Paper zuerst vollständig unterstützen.
3. Danach Fabric/Forge/NeoForge/Quilt/Purpur/Spigot/Folia ergänzen.
4. EULA-Bestätigung, Properties, RAM und Java-Kompatibilität.
5. Konsole, Spieleraktionen, Backups und Restore.
6. Bedrock/Geyser/Floodgate erst nach Java-Basis und Port-/UDP-Tests.

**Abnahme:** Frische Instanz startet, Client kann verbinden, Stop beendet Prozess, Backup kann wiederhergestellt werden.

### Phase 3 — Netzwerk und Playit
1. Vorhandenen Agentstatus vom Windows-PC verifizieren.
2. Bestehende Tunnel und externe Ports aus dem Playit-Dashboard dokumentieren.
3. TCP-Java und UDP-Bedrock getrennt testen.
4. Zuordnung pro Instanz mit Konfliktprüfung.
5. Nur bestätigte Hostnames/Ports veröffentlichen.

**Abnahme:** Externer Java- und Bedrock-Client kann über die jeweils zugewiesene Adresse verbinden; Neustart verändert Zuordnung nicht ungewollt.

### Phase 4 — Launcher und Microsoft-Login
1. OAuth-App-Registrierung und erlaubte Redirect-URIs konfigurieren.
2. Microsoft → Xbox Live → XSTS → Minecraft Services Ablauf implementieren und Fehlerfälle testen.
3. Token sicher speichern und erneuern; Logout/Revoke.
4. Minecraft-Version installieren, Assets prüfen und Spielprozess starten.
5. RAM-/Java-Auswahl, Logs, Crash Analyzer und Updates.

**Abnahme:** Benutzer meldet sich mit eigenem berechtigtem Microsoft-Konto an und startet eine lokal installierte Version ohne fremde Zugangsdaten.

### Phase 5 — Modrinth
1. Suche und Filter.
2. Kompatible Versionen und Loader prüfen.
3. Abhängigkeiten auflösen und atomar installieren.
4. Update/Rollback und Modpack-Import/Export.
5. Shader, Resource Packs und Datapacks.

**Abnahme:** Modpack lässt sich installieren, starten, aktualisieren und bei Fehler zurückrollen.

### Phase 6 — Konten, Credits, Premium und Admin
1. Authentifizierung, Verifikation, Reset und Sessions.
2. Rollen-/Rechtesystem serverseitig.
3. Credits-Ledger und 10.000 Startguthaben.
4. Premium-Entitlements und Admin-Freischaltung.
5. Audit-Logs, 2FA und Abuse-Limits.

**Abnahme:** Client kann Rechte nicht selbst erhöhen; doppelte Requests buchen Credits nicht doppelt; Admin-Aktionen sind nachvollziehbar.

### Phase 7 — Community und Komfort
1. Freunde, Einladungen, Gruppen.
2. Benachrichtigungen.
3. Opt-in Serverliste, Bewertungen und Moderation.
4. Chat nur nach Sicherheits-/Datenschutzkonzept.

### Phase 8 — Release und Betrieb
1. Windows-Installer/EXE signieren.
2. Auto-Update mit Integritätsprüfung und Rollback.
3. Installations-/Upgrade-/Deinstallations-Tests.
4. Restore-Drills, Lasttests, Penetrationstest der lokalen Agent-API.
5. Release-Checkliste und Support-/Recovery-Dokumentation.

## Architekturprinzipien
- Windows-first, zunächst ein eigener Hosting-Node.
- Desktop-App (Electron) spricht nur über abgesicherte Preload-/IPC-Schnittstellen mit dem lokalen Backend.
- Webserver, Auth-Service und Node-Agent haben getrennte Verantwortlichkeiten.
- Kein beliebiger Shell-Command-Endpunkt; Aktionen sind typisierte, validierte Operationen.
- Pro Serverinstanz eigene UUID, Datenpfad, Prozess und Berechtigungsprüfung.
- Secrets nur serverseitig bzw. im Windows Credential Manager; `.env` bleibt lokal.
- Externe Dienste (Microsoft, Modrinth, Playit) über dokumentierte Schnittstellen; keine erfundenen APIs.
- Jede UI-Aktion zeigt echten Status oder klar „noch nicht verbunden“.

## Release-Checkliste
- [ ] Originalprojekt-Backup und Migration getestet
- [ ] Keine Secrets in ZIP/Git/Logs
- [ ] Agent-API nur lokal/mit Auth erreichbar
- [ ] Benutzer- und Instanzisolation getestet
- [ ] Port-/Prozessbereinigung getestet
- [ ] Backup und Restore getestet
- [ ] Java/TCP und Bedrock/UDP extern getestet
- [ ] Microsoft OAuth mit eigenem Testkonto geprüft
- [ ] Modrinth Install/Update/Rollback geprüft
- [ ] Credits/Rollen serverseitig geprüft
- [ ] Windows Installer, Update und Rollback geprüft
- [ ] Fehler-/Recovery-Dokumentation vorhanden

## Was für die echte Fertigstellung noch benötigt wird
- Der aktuelle vollständige Quellcode vom Windows-PC (ohne `node_modules`, `.git`, `.env`, Tokens, Zertifikate oder private Schlüssel), damit Änderungen in genau deinen aktuellen Stand integriert werden können.
- Microsoft Entra/App-Registrierung mit passenden Redirect-URIs; Client-Secret niemals in den Chat posten.
- Zugriff auf deinen PC für Build- und Funktionstests durch dich; ich kann den lokalen Windows-Prozess nicht selbst ausführen.
- Playit-Tunnel-/Portdetails aus deinem Dashboard; Agent-Secrets niemals teilen.
- Domain/DNS nur falls eigene dauerhafte Domain gewünscht ist.
