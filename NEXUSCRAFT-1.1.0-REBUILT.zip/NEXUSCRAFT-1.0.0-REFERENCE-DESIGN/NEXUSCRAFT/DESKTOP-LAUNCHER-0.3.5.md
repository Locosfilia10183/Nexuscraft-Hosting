# NEXUSCRAFT Windows Launcher 0.3.5

This update adds dedicated quick actions to the Windows desktop launcher server list:
- start / stop / restart
- player lookup and OP/deop/ban/kick commands through the authenticated server console
- recent console log and command sending
- backup creation

These actions require the NEXUSCRAFT web panel to be running, the user to be signed in, and the server to be owned by that account (or admin). OP is a Minecraft server permission, not a website account role. Use commands only on servers you administer.

## Build on Windows
From the extracted project root in PowerShell:

```powershell
cd desktop-launcher
npm install
npm run dist:win
```

The installer and portable executable are written to `desktop-launcher\dist`. This source package does not contain a prebuilt or code-signed EXE. Microsoft sign-in, game installation, modloader installation, and full game launch still require end-to-end testing on the target PC.
