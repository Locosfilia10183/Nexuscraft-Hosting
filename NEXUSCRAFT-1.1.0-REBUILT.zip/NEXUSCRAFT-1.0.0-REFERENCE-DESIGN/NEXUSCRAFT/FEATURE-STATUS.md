# Feature-Status — ehrliche Bestandsaufnahme

Dieser Status beschreibt den ZIP-Inhalt und bekannte bisherige Arbeitsschritte, nicht einen aktuell laufenden Live-Server. Neue Anforderungen sind vollständig in `FEATURES-EXPANSION-SPEC-DE.md` erfasst.

| Bereich | Status im Paket | Hinweis |
|---|---|---|
| Webserver / Agent-Grundlage | Vorhanden | Auf dem Ziel-PC erneut testen |
| Electron-Desktop-Launcher | Vorhanden | Build/IPC lokal prüfen |
| Minecraft-Serverprozess-Management | Teilweise / zu verifizieren | Nicht als produktionsreif behandeln |
| Microsoft OAuth / echter Minecraft-Start | Offen / nicht nachgewiesen | End-to-End-Test erforderlich |
| Modrinth Modpack-Installation | Teilweise / zu verifizieren | Abhängigkeiten, Hashes und Rollback testen |
| Game Library / Profile | Teilweise / zu verifizieren | Vollständige Profilverwaltung abnehmen |
| Shader & Resource Manager | Spezifikation vorhanden | Implementierung/Tests offen |
| Java-Server | Früher lokal getestet | Paper 1.21.4, 2 GB, 10 Spieler, Port 25565 war der bekannte Teststand |
| Fabric-Modpack | Offen | Bekannter Versionskonflikt: Modpack 1.21.1 vs Paper 1.21.4 |
| Bedrock/Geyser/Floodgate | Offen / nicht nachgewiesen | UDP-Tunnel und externe Verbindung testen |
| Playit-Agent | Bereits verbunden gemeldet | Vorhandener Agent `from-key-5eaf`; Tunnelzuordnung erneut prüfen |
| Playit automatische Tunnelverwaltung | Offen / nicht nachgewiesen | Nur mit bestätigter unterstützter Schnittstelle integrieren |
| Backups / Restore | Teilweise / zu verifizieren | Integritäts- und Wiederherstellungstest erforderlich |
| Plugin Manager / Templates / Tasks | Spezifikation vorhanden | Implementierung offen |
| Community / Chat / Freunde / Reviews | Spezifikation vorhanden | Backend, Moderation und Datenschutz offen |
| Admin / Credits / Premium | Teilweise / zu verifizieren | Ledger, Rollen und Audit-Logs testen |
| 2FA / Remote Access / Alerts | Spezifikation vorhanden | Implementierung und Security Review offen |
| EXE/Installer | Build-Skript vorhanden | Installations- und Update-Test erforderlich |

**Regel:** Ein Eintrag gilt erst nach reproduzierbarem Test als „fertig“. Siehe `TONIGHT-CLIENT-CHECKLIST-DE.md` für den nächsten PC-Termin.
