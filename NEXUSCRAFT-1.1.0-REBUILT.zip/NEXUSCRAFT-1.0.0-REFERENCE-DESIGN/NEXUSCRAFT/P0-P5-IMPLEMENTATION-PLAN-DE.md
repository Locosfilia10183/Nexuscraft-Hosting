# NEXUSCRAFT P0–P5 – Umsetzungsplan und Abnahme

Dieses Dokument ist die verbindliche technische Arbeitsgrundlage. Es unterscheidet vorhandene Grundlagen von nicht nachgewiesenen Integrationen. Ein Modul wird erst nach reproduzierbarem Test als fertig markiert.

## P0 – Sicherheit und Betrieb (Blocker vor öffentlichem Betrieb)
- [ ] Tenant-Isolation: jede Server-/Datei-/Backup-/Konsole-Aktion serverseitig an Eigentümer und Rolle binden; Pfadzugriffe ausschließlich über kanonische Instanzverzeichnisse.
- [ ] Rollen: owner, admin, moderator, support, user; Least-Privilege-Prüfung je Route.
- [ ] 2FA (TOTP): Enrollment mit QR/Secret, einmalige Recovery-Codes gehasht speichern, Step-up bei kritischen Aktionen.
- [ ] Audit-Log: Login, Rollen, Credits, Premium, Server-Lifecycle, Restore, Tunneländerungen; manipulationsarme Speicherung.
- [ ] Backups: atomare Erstellung, SHA-256-Manifest, Retention, Restore in temporäres Verzeichnis und Validierung vor Austausch.
- [ ] Remote Access: HTTPS, sichere Cookies, CSRF-/Origin-Schutz, Rate Limits, Agent-Token-Rotation, keine offenen Admin-Ports.
- [ ] Ressourcenlimits: CPU/RAM/Disk/Prozesslimits pro Instanz; harte Quoten statt UI-Anzeige allein.
- Abnahme: Negativtests mit zwei Konten; Konto A kann weder Konsole, Dateien, Backups noch Metriken von B lesen oder verändern.

## P1 – Launcher und persönliche Bibliothek
- [ ] Profile/Instanzen mit Version, Loader, Java-Pfad, RAM, Spielverzeichnis und Modliste.
- [ ] Cloud Sync mit Konflikterkennung, Versionsnummern und explizitem Restore; keine stillen Überschreibungen.
- [ ] Themes, Screenshot-Galerie und FPS-/RAM-Overlay (nur lokal und mit Opt-in).
- [ ] Microsoft-Login und Minecraft-Entitlement vor echtem Start serverseitig/über offizielle Flows prüfen.
- [ ] Modrinth: Projekt-/Versionsauflösung, Loader-/Game-Version-Filter, Abhängigkeiten, Hashprüfung, atomare Installation und Rollback.
- Abnahme: Installation eines Testprofils, Start eines echten Spiels, Offline-/Login-Fehler sauber anzeigen.

## P2 – Hosting-Kern
- [ ] Multi-node-Registry und Health Checks; Scheduling nach Kapazität.
- [ ] Server-Netzwerk (Lobby/Proxy/Backend) mit expliziter Proxy-Konfiguration und Firewall-Regeln.
- [ ] Automations-Builder mit Allowlist für Aktionen, Zeitplan, Sperren gegen parallele Tasks und Audit.
- [ ] Testserver-Klon: konsistenter Snapshot, getrennte Ports/IDs, kein unbeabsichtigtes Produktionsrouting.
- [ ] Weltkarte über unterstützte Serverintegration; Zugriff nur für freigegebene Spieler.
- [ ] Live-Analytics aus echten Agent-Metriken, keine erfundenen Werte.
- Abnahme: Start/Stop/Restart, Crash-Recovery mit Backoff, Clone-Test und Portkonflikt-Test.

## P3 – Community
- [ ] Voice-Räume über dedizierten WebRTC-SFU-Dienst; TURN, Moderation, Mute/Block und Einwilligung.
- [ ] Gruppen/Rollen/Einladungen mit Ablauf und Widerruf.
- [ ] Öffentliche Serverliste/Marketplace mit Melden, Moderation, Rate Limits und Sichtbarkeitseinstellungen.
- [ ] Events, Achievements und Creator-Profile; nur verifizierte Spiel-/Serverereignisse werten.
- Abnahme: Missbrauchs-/Spamtests, Meldeworkflow und Datenschutzeinstellungen.

## P4 – Premium und Entwicklerplattform
- [ ] Premium-Entitlements zentral und serverseitig durchsetzen; keine Freischaltung nur im Client.
- [ ] Server-Shop nur mit klarer Trennung von Plattform-Credits und Echtgeld; rechtliche/Payment-Prüfung vor Livebetrieb.
- [ ] Eigene Domains/Subdomains: DNS-Verifikation, TLS, Domain-Bindung und Kollisionsschutz.
- [ ] White-Label mit getrennten Tenants, Branding-Konfiguration und Mandantentests.
- [ ] Developer API mit OAuth/API-Keys, Scopes, Quotas, Rotation und Webhooks.
- Abnahme: Entitlement-Manipulation im Client darf Limits nicht umgehen.

## P5 – Mobile Verwaltung
- [ ] Responsive Web/PWA als erste sichere Mobile-Control-Oberfläche.
- [ ] iOS-App optional später; Push-Mitteilungen nur nach Berechtigung.
- [ ] Geräte-/Sitzungsverwaltung, biometrische Entsperrung optional, kurzlebige Tokens.
- [ ] Mobile Aktionen: Status, Start/Stop/Restart, Konsole mit Berechtigungsprüfung, Backups und Warnungen.
- Abnahme: Gerät widerrufen, verlorenes Gerät abmelden, kritische Aktionen bestätigen.

## Bestehender Stand – ehrlich
- Im Quellstand vorhanden: Node.js-Control-Plane, Benutzer-/Session-Grundlage, Admin-Routen, Agent-Kommunikation, Serverentwürfe/-erstellung und diverse Server-Endpunkte; Electron-Projekt und Build-Skripte sind vorhanden.
- Teilweise/zu verifizieren: Serverprozess-Management, Backups, Modrinth-Bibliothek, Launcher-IPC und vorhandene UI.
- Nicht als fertig nachgewiesen: Microsoft OAuth/echter Spielstart, sichere vollständige Tenant-Isolation, TOTP-2FA, Voice, Marketplace, White-Label, API-Scopes, PWA-Push, automatisches Playit-Tunnelmanagement.

## Reihenfolge für echte Umsetzung
1. P0-Isolation und Sicherheit vor allen öffentlichen Funktionen.
2. P1 echter Launcher-Flow und atomare Modpack-Installation.
3. P2 Hosting-Prozesse und Netzwerk, danach Analytics/Automation.
4. P5 mobile Verwaltung als responsive Weboberfläche.
5. P3 Community mit Moderation/Voice-Infrastruktur.
6. P4 Premium/Marketplace/White-Label/API nach Security- und Rechtsprüfung.

## Externe Voraussetzungen
- Microsoft/Xbox/Minecraft OAuth-App-Registrierung und zulässige Redirect-URIs.
- Domain/DNS und HTTPS-Zertifikate für öffentlichen Betrieb.
- Voice-SFU/TURN-Hosting, falls Voice wirklich live gehen soll.
- Externer Backup-Speicher mit Zugangsdaten und Verschlüsselungsschlüssel.
- Zahlungsanbieter und rechtliche Prüfung vor Echtgeld-/Shop-Funktionen.
- Playit: nur offiziell unterstützte Agent-/Tunnelsteuerung verwenden; bestehende Tunnel nicht als automatisch verwaltbar voraussetzen.
