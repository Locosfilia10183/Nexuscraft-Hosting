# NEXUSCRAFT 1.1.0

## Starten
1. Node.js LTS installieren.
2. Im Projektordner `npm install` ausführen.
3. `npm start` starten, danach `http://localhost:3000` öffnen.
4. Für den Desktop-Launcher in `desktop-launcher` wechseln, dort `npm install` und `npm start` ausführen.

## Windows-Build
Unter Windows `desktop-launcher\BUILD-WINDOWS.bat` starten. Der Build benötigt Internetzugang für npm/Electron und erstellt die Installer-Datei im Ordner `desktop-launcher\dist`.

## Funktionsstatus
Enthalten sind die bestehende Panel-Anmeldung, Serversteuerung über das verbundene Panel, Minecraft-Profilverwaltung, Mojang-Versionsliste, Microsoft-Anmeldung und Modrinth-Modpack-Suche/Import. Die Oberfläche kennzeichnet nicht angebundene Funktionen ausdrücklich.

Ein fertiger EXE-Build ist in diesem ZIP nicht enthalten.
