# NEXUSCRAFT Everything – Erweiterungsspezifikation

Stand: 09.11.2026  
Ziel: Eine zuverlässige Minecraft-Gaming-, Community- und Hosting-Plattform. Dieses Dokument ist die verbindliche Funktionsliste für die weitere Implementierung. Es behauptet nicht, dass die hier aufgeführten Funktionen bereits fertig sind.

## Produktprinzipien

1. **Echte Funktionen statt Attrappen:** Jede Schaltfläche muss eine echte Aktion auslösen oder klar als „in Entwicklung“ markiert sein.
2. **Sicherheit vor Komfort:** Autorisierung erfolgt serverseitig; der Desktop-Client darf keine Adminrechte selbst festlegen.
3. **Isolation:** Jede Instanz erhält eigene Verzeichnisse, Prozesse, Ports, Limits und Berechtigungen.
4. **Wiederherstellbarkeit:** Vor riskanten Dateioperationen automatische Sicherung und nachvollziehbare Rollback-Möglichkeit.
5. **Messwerte nur aus echten Quellen:** CPU/RAM/Netzwerk/Spielerzahlen werden vom Agent oder Minecraft-Query ermittelt. Keine erfundenen Live-Daten.
6. **Schrittweise Freigabe:** Jede Funktion benötigt automatisierte Tests und einen dokumentierten manuellen Abnahmetest.

## A. Desktop-Launcher und Game Library

### A1. Game Library
- Installierte Minecraft-Versionen und Profile auflisten.
- Version, Loader, Java-Pfad, RAM-Limit, Spielverzeichnis und zuletzt gestartet anzeigen.
- Profile erstellen, duplizieren, umbenennen, exportieren und löschen (mit Bestätigung).
- Installationsstatus und Speicherbedarf anzeigen.
- Vor dem Start prüfen: Java-Version, Dateien, Speicherplatz, Loader und Abhängigkeiten.
- Minecraft-Versionen ausschließlich über offizielle bzw. lizenzkonforme Metadaten beziehen; keine Authentifizierungs- oder Lizenzumgehung.

**Abnahme:** Ein Profil kann erstellt, gestartet, erneut geöffnet und ohne Datenverlust gelöscht werden. Ein ungültiger Java-Pfad liefert eine verständliche Fehlermeldung.

### A2. Modpack One-Click Installer
- Modrinth-Projekte und Versionen durchsuchen; Loader und Minecraft-Version filtern.
- Modpack-Version samt Manifest, Abhängigkeiten und Hashes herunterladen.
- Installation in ein isoliertes Profilverzeichnis.
- Vor Update/Downgrade Sicherung erstellen; bei Fehlern Rollback anbieten.
- Updates anzeigen und nur nach Bestätigung anwenden.
- Download-Fortschritt, Abbruch, Wiederaufnahme und Fehlerprotokoll.
- Keine fremden Dateien ungeprüft ausführen; Archivpfade gegen Path Traversal validieren.

**Abnahme:** Ein Modpack lässt sich installieren, starten, aktualisieren und auf die vorherige Version zurücksetzen.

### A3. Shader & Resource Manager
- Resource Packs, Shaderpacks und Screenshots/Instanzzuordnung verwalten.
- Installieren, aktivieren/deaktivieren, aktualisieren und entfernen.
- Kompatibilitätshinweise für Minecraft-Version und Grafik-Loader (z. B. Iris/OptiFine) anzeigen.
- Vorhandene Dateien nicht ungefragt überschreiben.

**Abnahme:** Pack installieren, im richtigen Profil ablegen, aktivieren und wieder entfernen.

### A4. Freunde und Einladungen im Client
- Freundschaftsanfrage senden/annehmen/ablehnen/blockieren.
- Online-Status nur mit ausdrücklicher Datenschutzeinstellung anzeigen.
- Servereinladung mit Ablaufdatum und widerrufbarem Token.
- Einladung öffnet den Serverdialog; sie darf niemals automatisch unbekannte Dateien ausführen.

## B. Hosting Control Plane und Agent

### B1. Live Server Dashboard
- Status: gestoppt, startend, online, stoppend, Fehler.
- CPU/RAM/Datenträger/Netzwerk aus Agent-Metriken; Zeitstempel und Aktualität sichtbar.
- Spielerzahl über unterstützte Status-/Query-Schnittstelle, sonst „nicht verfügbar“.
- Uptime aus Prozessstartzeit.
- Warnschwellen pro Server konfigurierbar.

### B2. Web-Konsole
- Live-stdout/stderr streamen, paginierte Logs und Suche.
- Befehle nur für berechtigte Nutzer; Rollenprüfung pro Instanz.
- Gefährliche Befehle optional bestätigen; jede Aktion protokollieren.
- Konsolenzugriff über authentifizierten WebSocket mit kurzlebigem Ticket.
- Keine direkte öffentliche Freigabe des lokalen Agent-Ports.

### B3. Automatische Backups
- Manuelle und geplante Sicherungen; Zeitplan mit Zeitzone.
- Weltdateien und Konfiguration konsistent sichern; bei Bedarf Minecraft-save-all/save-off/save-on verwenden.
- Retention-Regeln nach Anzahl/Alter; Speicherverbrauch anzeigen.
- Integritätsprüfung, Download und Wiederherstellung.
- Restore nur nach Serverstopp und mit zusätzlicher Sicherung des aktuellen Zustands.

### B4. Plugin Manager
- Suche und Metadaten für kompatible Quellen (z. B. Modrinth; weitere Anbieter nur bei erlaubter API-Nutzung).
- Servertyp, Minecraft-Version und Plugin-Kompatibilität prüfen.
- Download mit Hashprüfung; Quarantäne/Backup vor Austausch.
- Installieren, aktualisieren, deaktivieren und entfernen.
- Lizenz-/Nutzungsbedingungen und externe Downloadbeschränkungen beachten.

### B5. Server Templates
- Vorlagen für Vanilla, Paper, Purpur, Fabric, Forge, NeoForge, Quilt, Spigot und Folia.
- Vorlagen definieren Version, Startparameter, Standardkonfiguration und optionale Plugins/Mods.
- Keine veralteten oder nicht kompatiblen Versionen stillschweigend installieren.

### B6. Scheduled Tasks
- Geplante Neustarts, Backups, Updateprüfungen und Wartungsfenster.
- Zeitplan mit Zeitzone, nächster Ausführung und Ausführungsverlauf.
- Tasks müssen pausierbar, bearbeitbar und löschbar sein.

### B7. Auto-Recovery und Crash Analyzer
- Unerwartetes Prozessende erkennen und Crash-Logs sichern.
- Neustart mit begrenzter Versuchszahl und exponentiellem Backoff.
- Neustart-Schleifen automatisch stoppen und Admin warnen.
- Crash Analyzer fasst Logs zusammen und nennt belegte Hinweise; keine ungesicherten Ursachenbehauptungen.

### B8. Resource Alerts
- RAM-/CPU-/Speicher-/Netzwerk-Schwellen pro Server.
- Entprellung und Cooldown gegen Alarmfluten.
- Benachrichtigung im Client/Web; E-Mail/Push nur nach Konfiguration.

## C. Community-Plattform

### C1. Konten und Profile
- Gemeinsame Identität für Website und Desktop-Client.
- Profilname, Avatar, Kurzbeschreibung und Privatsphäre-Einstellungen.
- E-Mail-Verifizierung, Passwort-Reset und Sitzungsverwaltung.
- Optional Zwei-Faktor-Authentifizierung (TOTP mit Recovery-Codes).

### C2. Chat, Gruppen und Benachrichtigungen
- 1:1- und Gruppenchats, Blockieren/Melden, Rate Limits und Spam-Schutz.
- Nachrichtenberechtigungen und Aufbewahrungsregeln.
- Benachrichtigungszentrum mit gelesen/ungelesen und Einstellungen.
- WebSocket-Verbindung mit erneuter Authentifizierung und Reconnect.

### C3. Öffentliche Serverliste und Bewertungen
- Server nur nach expliziter Veröffentlichung aufführen.
- Felder: Name, Beschreibung, Spielversion, Java/Bedrock, Tags, Status, Spielerzahl (nur echte Messung).
- Melden, Moderation, Bewertung nur durch angemeldete Nutzer; Missbrauchsschutz.
- Keine Veröffentlichung privater IP-Adressen oder interner Agent-Adressen.

### C4. Spielzeit-Statistiken
- Spielzeit nur aus nachvollziehbaren Launch-/Server-Sitzungen.
- Nutzer können Erfassung deaktivieren und Datenexport/Löschung beantragen.
- Keine Behauptung von Spielzeit, wenn keine Messquelle existiert.

## D. Admin-Control-Center

- Benutzer suchen, Rollen verwalten, sperren/entsperren und Sitzungen widerrufen.
- Premium manuell freischalten/entziehen; Grund, Admin und Zeitstempel protokollieren.
- Credits vergeben/abbuchen ausschließlich über serverseitige Ledger-Einträge.
- Serverlimits: Anzahl, RAM, CPU-Anteil, Speicher, Ports, Spieler und Backup-Kontingent.
- Server und Nodes überwachen; Start/Stopp nur mit Berechtigung und Bestätigung.
- Audit-Log für Login, Rollen, Credits, Premium, Serveraktionen, Dateiaktionen und Wiederherstellungen.
- Notfall-Stopp: Bestätigung, Zusammenfassung der betroffenen Instanzen, geordneter Stopp, Ergebnisbericht.
- Adminaktionen dürfen nicht allein durch versteckte UI-Elemente geschützt werden; jede API prüft die Rolle.

## E. Premium, Credits und Abrechnung

- Pläne definieren Limits zentral und versioniert.
- Premium-Funktionen: mehr RAM, Server, Backups, Spieler, Statistiken, Server-Icons und Premium-Modpack-Funktionen.
- Credits: unveränderliches Ledger mit Buchungstyp, Betrag, Referenz, Ersteller und Zeitstempel.
- Keine negativen oder doppelten Buchungen; Idempotency Keys für wiederholte Requests.
- Kauf-/Zahlungsintegration erst nach Anbieterprüfung, Webhook-Signaturprüfung und Testmodus.
- Eigene Subdomains nur mit echter Domain, DNS-Verwaltung und Konfliktprüfung. `.craft` ist keine allgemein registrierbare öffentliche DNS-Endung.

## F. Remote Access und Sicherheit

- Handyverwaltung über HTTPS-Weboberfläche/PWA.
- Agent baut ausgehend eine authentifizierte Verbindung auf; keine offene Admin-API ins Internet.
- Agent-Token rotierbar, widerrufbar und nur gehasht bzw. sicher gespeichert.
- TLS, sichere Cookies, CSRF-Schutz, Rate Limits, Eingabevalidierung und Security Headers.
- Prozessstart nur mit erlaubten ausführbaren Dateien und validierten Argumenten; keine frei zusammengesetzten Shell-Befehle.
- Serververzeichnisse strikt unter einem konfigurierten Root halten; Symlink-/Traversal-Prüfungen.
- Ports exklusiv reservieren und Kollisionen verhindern.
- Secrets niemals in ZIP, Git, Logs oder Screenshots ablegen.
- Backup-Verschlüsselung optional mit dokumentierter Schlüsselverwaltung.

## G. Playit.gg und Netzwerk

- Bestehenden Agent weiterverwenden; Agentstatus und Tunnelstatus getrennt darstellen.
- Java-Tunnel benötigt TCP, Bedrock-Tunnel UDP.
- Pro Instanz eindeutige lokale Zielports und bestätigte externe Zuweisungen.
- Tunnel automatisch nur dann erstellen/ändern, wenn Playit eine dokumentierte und für das Konto verfügbare API/Funktion bereitstellt. Andernfalls geführte manuelle Einrichtung.
- Keine erfundenen Hostnamen oder Ports. Öffentliche Adresse erst nach erfolgreichem Verbindungstest als aktiv anzeigen.

## H. Datenmodell – Mindestentitäten

- `users`: id, email, password_hash/external_auth_id, status, created_at
- `user_roles`: user_id, role, scope
- `sessions`: id, user_id, expires_at, revoked_at
- `user_profiles`: user_id, display_name, avatar, bio, privacy_json
- `two_factor`: user_id, secret_encrypted, enabled_at, recovery_hashes
- `friendships`: requester_id, addressee_id, status, timestamps
- `groups`, `group_members`, `messages`, `notifications`
- `nodes`: id, owner_id, agent_id, status, last_seen_at
- `servers`: id, owner_id, node_id, name, type, version, status, root_path
- `server_limits`: server_id, ram_mb, cpu_limit, disk_mb, player_limit
- `server_ports`: server_id, protocol, local_port, public_host, public_port, verified_at
- `server_metrics`: server_id, captured_at, cpu, memory, network_in, network_out, players
- `backups`: server_id, path, size, checksum, created_at, status
- `scheduled_tasks`: server_id, type, schedule, timezone, enabled
- `crash_events`: server_id, exit_code, log_path, summary, created_at
- `credits_ledger`: user_id, amount, reason, reference, actor_id, created_at
- `entitlements`: user_id, plan, features_json, starts_at, ends_at
- `server_reviews`, `public_listings`, `reports`
- `audit_logs`: actor_id, action, target_type, target_id, metadata_json, created_at

Alle Fremdschlüssel, eindeutigen Constraints, Indizes und Transaktionen sind in der konkreten Datenbankmigration festzulegen. Passwörter niemals im Klartext speichern.

## I. API-/Event-Verträge (Ziel)

REST-Beispiele (konkrete Pfade und Schemas werden beim Implementieren versioniert):
- Auth: register, login, logout, refresh, verify-email, password-reset, 2FA
- Profile/Friends: profile CRUD, friend requests, block/report
- Servers: create, list, get, start, stop, restart, delete, console command
- Files: list, upload, download, rename, delete (nur innerhalb Server-Root)
- Backups: create, list, verify, restore, download
- Modpacks/Plugins: search, inspect, install, update, remove
- Admin: users, entitlements, credits ledger, limits, audit logs, emergency stop
- Community: chat, groups, listings, reviews, notifications
- Agent events: heartbeat, server status, metrics, console output, crash, task result

Jeder schreibende Endpunkt benötigt Authentifizierung, Autorisierung, Validierung, Rate Limit, Audit-Eintrag (wo relevant) und idempotentes Verhalten bei wiederholbaren Aktionen.

## J. Umsetzung und Freigabe-Reihenfolge

### Phase 0 – Bestand sichern und reproduzierbar machen
- ZIP/Projekt sichern, Secrets entfernen, `.env.example` prüfen.
- Node-/Java-Versionen und Startskripte dokumentieren.
- Smoke Tests für Webserver, Agent und Launcher.

### Phase 1 – Zuverlässiger Kern
- Datenbankmigrationen, Auth/Sessions/Rollen.
- Agent-Authentifizierung, Serverisolierung, Portreservierung.
- Echte Serverprozesse, Logs, Status und Metriken.
- Backups und Restore.

### Phase 2 – Launcher
- Microsoft-Login gemäß offiziellen OAuth-/Minecraft-Regeln.
- Game Library, Versionen, Java-Prüfung und echter Start.
- Modrinth-Profile und Modpack-Installation.
- Shader-/Resource-Manager.

### Phase 3 – Hosting-Produkt
- Plugin Manager, Templates, Web-Konsole.
- Geyser/Floodgate und Java-/Bedrock-Tests.
- Playit-Status/Tunnel-Verknüpfung mit verifizierten Adressen.
- Scheduled Tasks, Auto-Recovery, Crash Analyzer und Alerts.

### Phase 4 – Community und Monetarisierung
- Profile, Freunde, Gruppen, Chat, Benachrichtigungen.
- Öffentliche Serverliste, Reviews und Spielzeit.
- Credits Ledger, Premium, Admin-Control-Center.
- 2FA, Audit-Logs, Remote Access.

### Phase 5 – Release
- Windows Installer/EXE signieren (wenn Zertifikat vorhanden).
- Upgrade-/Rollback-Test, Backup-/Restore-Test, Rechte-/Isolationstest.
- Lasttest und Security Review.
- Release-Notes, Recovery-Anleitung und Support-Diagnosepaket.

## K. Release-Gates – keine Funktion gilt ohne diese Tests als fertig

- Unit-/Integrationstest erfolgreich.
- Negativtest: unberechtigter Nutzer kann fremden Server nicht sehen/steuern.
- Pfadtests: `..`, Symlinks und manipulierte Archive können Server-Root nicht verlassen.
- Prozess-/Porttests: Start, Stop, Crash, Neustart, Kollision und Shutdown.
- Backup-Test: Integrität und vollständige Wiederherstellung.
- Netzwerk: Java TCP und Bedrock UDP von einem externen Anschluss getestet.
- Launcher: OAuth und echter Minecraft-Start mit berechtigtem Konto.
- Updates: fehlgeschlagenes Update lässt vorherigen Zustand wiederherstellen.
- Logs enthalten keine Tokens, Passwörter oder privaten Schlüssel.

## Aktueller Implementierungsstatus

Diese Spezifikation erweitert den bisherigen Projektstand um alle vom Nutzer gewünschten Produktbereiche. Sie ist **Plan und Abnahmekatalog**, keine Behauptung einer bereits erfolgten Implementierung. Der tatsächliche Code muss im Anschluss anhand der obigen Phasen ergänzt und auf dem Windows-Ziel-PC getestet werden.
