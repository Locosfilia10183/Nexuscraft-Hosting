# NEXUSCRAFT 0.5.1 – Release-Check

## Grundlage
Diese Version baut direkt auf dem gelieferten Projektstand 0.5.0 auf. Bestehende Control-Plane-, Agent-, Launcher-, Community- und Operations-Center-Dateien bleiben enthalten.

## Änderung in 0.5.1
- SMP-Online-Status läuft ab, wenn kein frischer authentifizierter Heartbeat eintrifft.
- Standard-Zeitfenster: 90 Sekunden (`NEXUS_SMP_HEARTBEAT_TTL_MS`).
- Nach Ablauf: `online=false`, `players=0`; das Operations Center verwendet dieselbe Prüfung.
- Neuer Integrationstest prüft gültigen Heartbeat, Ablauf und konsistenten Status.

## Verifikation in der Build-Umgebung
- `npm run check:features`: bestanden.
- `npm test`: 2 Tests bestanden (2FA/Sitzungen und SMP-Heartbeat-Ablauf).

## Nicht behauptet / weiterhin externe Schritte
- Kein VPSLab-Zugriff oder Deployment durchgeführt.
- Kein echter öffentlicher SMP-Node oder Heartbeat-Dienst eingerichtet.
- Keine Stripe-Livezahlung, SMTP-Zustellung, Domain-/HTTPS- oder Minecraft-Ende-zu-Ende-Prüfung.
- Launcher-Build für Windows wurde nicht ausgeführt.

## Upgrade
1. Projektordner sichern.
2. ZIP in einen neuen Ordner entpacken und lokale Konfiguration aus `.env` sowie Daten-/Agent-Verzeichnisse separat übernehmen.
3. `.env.example`-Eintrag `NEXUS_SMP_HEARTBEAT_TTL_MS` optional übernehmen; Standard sind 90 Sekunden.
4. `npm install`, dann `npm run check:features` und `npm test` ausführen.
5. Erst nach eigener Prüfung in die bestehende Installation übernehmen.

Keine `.env`, `data.json`, `nodes.json`, `feature-data.json`, `agent/agent-config.json`, Serverwelten oder Backups sind in dieser Quellcode-ZIP enthalten.
