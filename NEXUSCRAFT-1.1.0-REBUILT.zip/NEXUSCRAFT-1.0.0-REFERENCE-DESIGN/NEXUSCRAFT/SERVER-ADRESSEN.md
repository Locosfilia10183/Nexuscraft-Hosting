# NEXUSCRAFT – Serveradressen

Jeder Server erhält eine stabile Adresse, die im Server-Dashboard angezeigt wird.

- `PUBLIC_SERVER_HOST`: öffentliche IP oder Hostname des Windows-Hosts.
- `NEXUSCRAFT_DOMAIN`: optional eigene Domain. Dann wird pro Server eine Subdomain aus Servernamen und kurzer Server-ID gebildet. Im DNS muss ein Wildcard-Eintrag `*.deine-domain.tld` auf die öffentliche IP zeigen.
- Java verwendet den zugewiesenen TCP-Port (standardmäßig 25565, weitere Server erhalten weitere Ports).
- Bedrock wird nur für Server mit Java+Bedrock/Crossplay angezeigt. Geyser/Floodgate und eine erreichbare UDP-Portfreigabe sind erforderlich. Der Agent verwendet in dieser Version den Geyser-Standardport UDP 19132; mehrere Crossplay-Server auf demselben Node benötigen vor öffentlichem Betrieb eine separate UDP-Portzuweisung und passende Geyser-Konfiguration.

`127.0.0.1` ist ausschließlich lokal auf dem Host erreichbar. Für andere Spieler muss `PUBLIC_SERVER_HOST` auf die öffentliche IP oder Domain gesetzt und die jeweiligen TCP-/UDP-Ports in Router und Windows-Firewall freigegeben werden. Keine Ports öffentlich öffnen, bevor Authentifizierung, Firewall und Geyser-Portzuweisung geprüft sind.
