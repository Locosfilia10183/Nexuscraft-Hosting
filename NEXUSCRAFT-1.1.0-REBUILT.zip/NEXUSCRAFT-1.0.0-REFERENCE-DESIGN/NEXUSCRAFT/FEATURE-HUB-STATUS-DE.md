# NEXUSCRAFT Hub – Entwicklungsstand

Diese Erweiterung ergänzt den bestehenden Control-Plane-Server additiv. Sie verwendet `feature-data.json`, damit das vorhandene `data.json`-Kontoschema nicht migriert oder überschrieben werden muss.

## In diesem Paket implementiert
- Eigenständige Hub-Oberfläche unter `/community.html`, mobil nutzbar.
- Spielerprofil mit Bio/Titel und eigener Profilkarte.
- Freundschaftsanfragen und Annahme; Gruppen erstellen und auflisten.
- Kuratierter Marketplace-Katalog mit offiziellen Projektlinks (keine automatische Installation aus diesem Katalog).
- Öffentlicher SMP-Status-Endpunkt; zeigt offline, bis ein authentifizierter Heartbeat empfangen wird.
- Geschützter SMP-Heartbeat über `NEXUS_SMP_HEARTBEAT_TOKEN`.
- BlueMap/Dynmap-Linkanzeige, sobald eine HTTPS-Kartenadresse im Heartbeat registriert ist.
- Regelbasierte Log-Erstdiagnose; ausdrücklich keine externe generative KI.
- Optimizer-Hinweise aus übermittelten Messwerten; ändert keine Serverkonfiguration.
- Autopilot-Einstellungs- und Ereignisspeicher; führt noch keine Neustarts/Reparaturen aus.

## Noch nicht produktionsfertig / externe Voraussetzungen
- SMP läuft nicht automatisch: separater Server, Domain/Ports, Java/Paper/Purpur, Geyser und Floodgate müssen eingerichtet und getestet werden.
- Heartbeat-Client/Monitoring-Dienst muss am separaten SMP-Node eingerichtet werden.
- 24/7-Verfügbarkeit benötigt einen bezahlten/zuverlässigen separaten Host, Strom/Netzwerk, Monitoring und Backups.
- Chat, Gruppeneinladungen, Online-Präsenz, Benachrichtigungen und Freundesverwaltung mit Entfernen/Blockieren sind noch nicht fertig.
- Marketplace-Download, Signatur-/Malware-Prüfung und Installation sind noch nicht angebunden.
- Live World Map benötigt BlueMap/Dynmap und eine echte Karten-URL.
- NEXUS AI benötigt später einen bewusst konfigurierten KI-Anbieter; aktuell nur lokale Mustererkennung.
- Autopilot benötigt echte Node-Metriken, Policy-Engine, Freigabe-Workflow und sichere Agent-Aktionen.
- Profil-Level/XPs sind aktuell nur Datenfelder, noch nicht mit SMP-Fortschritt synchronisiert.
- SMP-Status wird nicht erfunden: ohne gültigen Heartbeat bleibt er offline.

## Einrichtung
1. `.env.example` nach `.env` kopieren und `NEXUS_SMP_HEARTBEAT_TOKEN` mit einem starken Zufallswert ersetzen.
2. `.env` niemals veröffentlichen oder in ein ZIP/Git-Repository aufnehmen.
3. `npm start` starten und `/community.html` öffnen.
4. Auf der Hauptseite anmelden, damit Profil-/Community-Funktionen nutzbar sind.
5. Für öffentlichen Betrieb HTTPS, sichere Backups und separate SMP-Infrastruktur konfigurieren.

## Sicherheitshinweise
- `feature-data.json` enthält Community-Metadaten und wird lokal gespeichert. Für mehrere Instanzen ist eine gemeinsame transaktionale Datenbank erforderlich.
- Freundschaftsanfragen sind derzeit nicht mit E-Mail-/Push-Benachrichtigungen verbunden.
- Marketplace-Einträge sind Verweise auf offizielle Seiten. Keine beliebigen JAR-Dateien ungeprüft ausführen.
